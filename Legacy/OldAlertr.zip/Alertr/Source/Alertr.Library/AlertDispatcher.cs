﻿using System.Diagnostics.Contracts;
using System.Web;
using Twilio;
using System;

namespace Alertr.Library
{
    public static class AlertDispatcher
    {
        public static void SendEmailAlert()
        {
        }

        //[DllExport("Add", CallingConvention = CallingConvention.StdCall)]
        public static bool SendVoiceAlert(string sid, string token,
            string from, string to, string message, out RestException error)
        {
            Contract.Requires(!string.IsNullOrWhiteSpace(sid));
            Contract.Requires(!string.IsNullOrWhiteSpace(token));
            Contract.Requires(from.IsPhoneNumber());
            Contract.Requires(to.IsPhoneNumber());
            Contract.Requires(message.IsMessage(1000));

            error = null;

            var client = new TwilioRestClient(sid, token);

            var url = string.Format(
                "http://twimlets.com/message?Message={0}",
                HttpUtility.UrlEncode(message));

            var options = new CallOptions();

            options.From = from;
            options.To = to;
            options.Url = url;
            

            // AR there other options???????????????????????????????????????????????????
            options.Timeout = 5;
            options.IfMachine = "Hangup";


            var result = client.InitiateOutboundCall(options);

            if (result.RestException == null)
                return true;

            error = result.RestException;

            return false;
        }

        public static bool SendSmsAlert(string sid, string token,
            string from, string to, string message, out RestException error)
        {
            Contract.Requires(!string.IsNullOrWhiteSpace(sid));
            Contract.Requires(!string.IsNullOrWhiteSpace(token));
            Contract.Requires(from.IsPhoneNumber());
            Contract.Requires(to.IsPhoneNumber());
            Contract.Requires(message.IsMessage(140));

            error = null;

            var client = new TwilioRestClient(sid, token);

            var result = client.SendSmsMessage(from, to, message);

            if (result.RestException == null)
                return true;

            error = result.RestException;

            return false;
        }
    }
}
