﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Text;
using System.Web;
using Twilio;
using Twilio.TwiML;

namespace Alertr.CallDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            const string SID = "AC4d2e2cfff3e5c59ab1f9bc373fdcabd2";
            const string TOKEN = "786c624de2d51b96087de7d833f7ecd6";
            const string FROM = "5705078275";
            const string TO = "2153168538";

            RestException error;

            //if (SendSmsAlert(SID, TOKEN, FROM, TO, "Something bad happened!", out error))
            //{
            //    Console.WriteLine("The SMS message was sent!");
            //}
            //else
            //{
            //    Console.WriteLine("SMS Error: " + error.Message);
            //}

            if (SendVoiceAlert(SID, TOKEN, FROM, TO,
                "The rain in Spain falls mainly on the plain!", out error))
            {
                Console.WriteLine("The Alert Call was dispatched!");
            }
            else
            {
                Console.WriteLine("Alert Call Error: " + error.Message);
            }

            Console.WriteLine();
            Console.Write("Press any key to continue...");

            Console.ReadKey();
        }

        private static bool SendVoiceAlert(string sid, string token, string from,
            string to, string message, out RestException error)
        {
            Contract.Requires(!string.IsNullOrWhiteSpace(sid));
            Contract.Requires(!string.IsNullOrWhiteSpace(token));
            Contract.Requires(from.IsPhoneNumber());
            Contract.Requires(to.IsPhoneNumber());
            Contract.Requires(message.IsMessage(1000));

            error = null;

            var client = new TwilioRestClient(sid, token);            

            var url = string.Format(
                "http://twimlets.com/message?Message={0}",
                HttpUtility.UrlEncode(message));

            var options = new CallOptions();

            options.From = from;
            options.To = to;
            options.Url = url;

            var result = client.InitiateOutboundCall(options);

            if (result.RestException == null)
                return true;

            error = result.RestException;

            return false;
        }

        private static bool SendSmsAlert(string sid, string token,
            string from, string to, string message, out RestException error)
        {
            Contract.Requires(!string.IsNullOrWhiteSpace(sid));
            Contract.Requires(!string.IsNullOrWhiteSpace(token));
            Contract.Requires(from.IsPhoneNumber());
            Contract.Requires(to.IsPhoneNumber());
            Contract.Requires(message.IsMessage(140));

            error = null;

            var client = new TwilioRestClient(sid, token);

            var result = client.SendSmsMessage(from, to, message);

            if (result.RestException == null)
                return true;

            error = result.RestException;

            return false;
        }
    }
}
