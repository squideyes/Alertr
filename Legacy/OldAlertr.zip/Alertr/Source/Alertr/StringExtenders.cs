﻿using System.Diagnostics.Contracts;
using System.Text.RegularExpressions;

namespace Alertr
{
    public static class StringExtenders
    {
        private static Regex phoneNumberRegex = new Regex(
            @"^\d{10}$", RegexOptions.Compiled);

        public static bool IsPhoneNumber(this string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return phoneNumberRegex.IsMatch(value);
        }

        public static bool IsMessage(this string value, int maxLength)
        {
            Contract.Requires(maxLength >= 1 && maxLength < 8000);

            const string EXTRA = @"!#""%&\()*,.?+-/;:<=>_@$";

            if (string.IsNullOrWhiteSpace(value))
                return false;

            if (value != value.Trim())
                return false;

            if (value.Length > maxLength)
                return false;

            foreach (var c in value)
            {
                if (char.IsLetterOrDigit(c))
                    continue;

                if (EXTRA.Contains(c.ToString()))
                    continue;

                if (c == ' ')
                    continue;

                return false;
            }

            return true;
        }
    }
}
