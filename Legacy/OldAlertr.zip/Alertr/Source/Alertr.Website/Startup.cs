﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Alertr.Website.Startup))]
namespace Alertr.Website
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
