﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Twilio.TwiML;

namespace Alertr.Website.Controllers
{
    public class AlertController : Controller
    {
        //
        // GET: /Alert/
        public ActionResult Index()
        {
            var twiml = new TwilioResponse();
            
            twiml.Say("Hello Monkey!");

            return new Twilio.TwiML (twiml);
        }
    }
}